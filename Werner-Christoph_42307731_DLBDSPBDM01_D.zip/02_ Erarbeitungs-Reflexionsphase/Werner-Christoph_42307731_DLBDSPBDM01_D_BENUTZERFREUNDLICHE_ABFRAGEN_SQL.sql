-- Diese Abfrage liefert eine Liste der B�cher, die am h�ufigsten ausgeliehen wurden. Solche Berichte k�nnen helfen, die Beliebtheit bestimmter B�cher zu --- �berwachen und Trends zu erkennen.
-- Benutzerdefinierte Abfrage: Meistgeliehene B�cher
SELECT TOP 10 b.Titel, COUNT(a.AusleihID) AS AnzahlAusleihen
FROM B�cher b
JOIN Ausleihen a ON b.BuchID = a.BuchID
GROUP BY b.Titel
ORDER BY AnzahlAusleihen DESC




-- Benutzerdefinierte Abfrage: Suche nach B�chern eines bestimmten Verlages und einer bestimmten Sprache
-- Solche Abfragen sind n�tzlich, um gezielte Informationen basierend auf Benutzerpr�ferenzen abzurufen.

SELECT Titel, ISBN, JahrDerVeroeffentlichung, Zustand
FROM B�cher
WHERE VerlagID = 1 AND Sprache = 'DE';
