-- Dummy-Daten f�r Verlage
INSERT INTO Verlage (VerlagID, Name, Adresse) VALUES 
(1, 'Springer', 'Heidelberg'),
(2, 'Hanser', 'M�nchen'),
(3, 'Beck', 'M�nchen'),
(4, 'Fischer', 'Frankfurt am Main'),
(5, 'Reclam', 'Ditzingen'),
(6, 'Piper', 'M�nchen'),
(7, 'Rowohlt', 'Reinbek'),
(8, 'Suhrkamp', 'Berlin'),
(9, 'Klett-Cotta', 'Stuttgart'),
(10, 'dtv', 'M�nchen');

-- Dummy-Daten f�r Kategorien
INSERT INTO Kategorien (KategorieID, Name) VALUES 
(1, 'Roman'),
(2, 'Sachbuch'),
(3, 'Biografie'),
(4, 'Thriller'),
(5, 'Science Fiction'),
(6, 'Fantasy'),
(7, 'Kinderbuch'),
(8, 'Jugendbuch'),
(9, 'Ratgeber'),
(10, 'Krimi');

-- Dummy-Daten f�r Benutzende
INSERT INTO Benutzende (BenutzerID, Name, Adresse, Geburtsdatum, Telefonnummer, Email, Passwort, Registrierungsdatum) VALUES 
(1, 'Anna Schmidt', 'Dresden, Prager Stra�e 10', '1985-05-15', '0351-123456', 'anna.schmidt@example.com', 'hashed_password1', '2024-01-01'),
(2, 'Peter M�ller', 'Dresden, K�nigsbr�cker Stra�e 5', '1990-07-20', '0351-234567', 'peter.mueller@example.com', 'hashed_password2', '2024-01-02'),
(3, 'Maria Fischer', 'Dresden, Borsbergstra�e 12', '1978-01-30', '0351-345678', 'maria.fischer@example.com', 'hashed_password3', '2024-01-03'),
(4, 'Klaus Meier', 'Dresden, Bautzner Stra�e 18', '1965-11-11', '0351-456789', 'klaus.meier@example.com', 'hashed_password4', '2024-01-04'),
(5, 'Sabine Wagner', 'Dresden, Alaunstra�e 22', '1982-03-25', '0351-567890', 'sabine.wagner@example.com', 'hashed_password5', '2024-01-05'),
(6, 'Thomas Weber', 'Dresden, Zwinglistra�e 3', '1975-06-05', '0351-678901', 'thomas.weber@example.com', 'hashed_password6', '2024-01-06'),
(7, 'Monika Hofmann', 'Dresden, Ostra-Allee 7', '1995-08-14', '0351-789012', 'monika.hofmann@example.com', 'hashed_password7', '2024-01-07'),
(8, 'Stefan Richter', 'Dresden, Schandauer Stra�e 2', '1988-12-19', '0351-890123', 'stefan.richter@example.com', 'hashed_password8', '2024-01-08'),
(9, 'Julia Neumann', 'Dresden, Wiener Stra�e 8', '1992-04-03', '0351-901234', 'julia.neumann@example.com', 'hashed_password9', '2024-01-09'),
(10, 'Michael Becker', 'Dresden, Gro�enhainer Stra�e 15', '1980-09-23', '0351-012345', 'michael.becker@example.com', 'hashed_password10', '2024-01-10');

-- Dummy-Daten f�r B�cher
INSERT INTO B�cher (BuchID, Titel, ISBN, VerlagID, KategorieID, JahrDerVeroeffentlichung, Sprache, Zustand) VALUES 
(1, 'Der Prozess', '9783161484100', 1, 1, 1925, 'DE', 'Gut'),
(2, '1984', '9780452284234', 2, 5, 1949, 'EN', 'Sehr gut'),
(3, 'Der Hobbit', '9783551352244', 3, 6, 1937, 'DE', 'Akzeptabel'),
(4, 'To Kill a Mockingbird', '9780061120084', 4, 7, 1960, 'EN', 'Gut'),
(5, 'Brave New World', '9780060850524', 5, 5, 1932, 'EN', 'Sehr gut'),
(6, 'The Catcher in the Rye', '9780316769480', 6, 1, 1951, 'EN', 'Gut'),
(7, 'Das Kapital', '9783406708349', 7, 2, 1867, 'DE', 'Sehr gut'),
(8, 'The Great Gatsby', '9780743273565', 8, 1, 1925, 'EN', 'Gut'),
(9, 'Moby-Dick', '9780142437247', 9, 4, 1851, 'EN', 'Akzeptabel'),
(10, 'War and Peace', '9780199232765', 10, 1, 1869, 'RU', 'Gut');

-- Dummy-Daten f�r Autoren
INSERT INTO Autoren (AutorID, Name) VALUES 
(1, 'Franz Kafka'),
(2, 'George Orwell'),
(3, 'J.R.R. Tolkien'),
(4, 'Harper Lee'),
(5, 'Aldous Huxley'),
(6, 'J.D. Salinger'),
(7, 'Karl Marx'),
(8, 'F. Scott Fitzgerald'),
(9, 'Herman Melville'),
(10, 'Leo Tolstoy');

-- Dummy-Daten f�r BuchAutoren
INSERT INTO BuchAutoren (BuchID, AutorID) VALUES 
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8),
(9, 9),
(10, 10);

-- Dummy-Daten f�r Ausleihen
INSERT INTO Ausleihen (AusleihID, BenutzerID, BuchID, Ausleihdatum, Rueckgabedatum) VALUES 
(1, 1, 1, '2024-01-10', '2024-02-10'),
(2, 2, 2, '2024-01-15', '2024-02-15'),
(3, 3, 3, '2024-01-20', '2024-02-20'),
(4, 4, 4, '2024-01-25', '2024-02-25'),
(5, 5, 5, '2024-02-01', '2024-03-01'),
(6, 6, 6, '2024-02-05', '2024-03-05'),
(7, 7, 7, '2024-02-10', '2024-03-10'),
(8, 8, 8, '2024-02-15', '2024-03-15'),
(9, 9, 9, '2024-02-20', '2024-03-20'),
(10, 10, 10, '2024-02-25', '2024-03-25');

-- Dummy-Daten f�r Bewertungen
INSERT INTO Bewertungen (BewertungID, BenutzerID, BuchID, Bewertung, BewertungDatum) VALUES 
(1, 1, 1, 'Sehr gutes Buch!', '2024-02-11'),
(2, 2, 2, 'Sehr spannend!', '2024-02-16'),
(3, 3, 3, 'Fantastisch!', '2024-02-21'),
(4, 4, 4, 'Ein Klassiker.', '2024-02-26'),
(5, 5, 5, 'Sehr beeindruckend.', '2024-03-02'),
(6, 6, 6, 'Wirklich gut.', '2024-03-06'),
(7, 7, 7, 'Sehr informativ.', '2024-03-11'),
(8, 8, 8, 'Ein Muss.', '2024-03-16'),
(9, 9, 9, 'Sehr tiefgr�ndig.', '2024-03-21'),
(10, 10, 10, 'Ein Meisterwerk.', '2024-03-26');

-- Dummy-Daten f�r Reservierungen
INSERT INTO Reservierungen (ReservierungsID, BenutzerID, BuchID, Reservierungsdatum) VALUES 
(1, 1, 1, '2024-03-10'),
(2, 2, 2, '2024-03-15'),
(3, 3, 3, '2024-03-20'),
(4, 4, 4, '2024-03-25'),
(5, 5, 5, '2024-04-01'),
(6, 6, 6, '2024-04-05'),
(7, 7, 7, '2024-04-10'),
(8, 8, 8, '2024-04-15'),
(9, 9, 9, '2024-04-20'),
(10, 10, 10, '2024-04-25');

-- Dummy-Daten f�r Mahnungen
INSERT INTO Mahnungen (MahnungID, AusleihID, Mahndatum, Betrag) VALUES 
(1, 1, '2024-02-15', 5.00),
(2, 2, '2024-02-20', 5.00),
(3, 3, '2024-02-25', 5.00),
(4, 4, '2024-03-02', 5.00),
(5, 5, '2024-03-07', 5.00),
(6, 6, '2024-03-12', 5.00),
(7, 7, '2024-03-17', 5.00),
(8, 8, '2024-03-22', 5.00),
(9, 9, '2024-03-27', 5.00),
(10, 10, '2024-04-01', 5.00);

-- Dummy-Daten f�r Benachrichtigungen
INSERT INTO Benachrichtigungen (BenachrichtigungID, BenutzerID, Nachricht, GesendetAm) VALUES 
(1, 1, 'Ihr Buch ist bald f�llig.', '2024-02-01'),
(2, 2, 'Ihr Buch ist bald f�llig.', '2024-02-06'),
(3, 3, 'Ihr Buch ist bald f�llig.', '2024-02-11'),
(4, 4, 'Ihr Buch ist bald f�llig.', '2024-02-16'),
(5, 5, 'Ihr Buch ist bald f�llig.', '2024-02-21'),
(6, 6, 'Ihr Buch ist bald f�llig.', '2024-02-26'),
(7, 7, 'Ihr Buch ist bald f�llig.', '2024-03-03'),
(8, 8, 'Ihr Buch ist bald f�llig.', '2024-03-08'),
(9, 9, 'Ihr Buch ist bald f�llig.', '2024-03-13'),
(10, 10, 'Ihr Buch ist bald f�llig.', '2024-03-18');

-- Dummy-Daten f�r BenutzerB�cher
INSERT INTO BenutzerB�cher (BenutzerBuchID, BenutzerID, BuchID, Zustand, VerleihDauer, Abholort, Zeitslots, VersandOption) VALUES 
(1, 1, 1, 'Gut', 30, 'Dresden, Prager Stra�e 10', 'Mo-Fr 10:00-18:00', 1),
(2, 2, 2, 'Sehr gut', 30, 'Dresden, K�nigsbr�cker Stra�e 5', 'Mo-Fr 10:00-18:00', 1),
(3, 3, 3, 'Akzeptabel', 30, 'Dresden, Borsbergstra�e 12', 'Mo-Fr 10:00-18:00', 1),
(4, 4, 4, 'Gut', 30, 'Dresden, Bautzner Stra�e 18', 'Mo-Fr 10:00-18:00', 1),
(5, 5, 5, 'Sehr gut', 30, 'Dresden, Alaunstra�e 22', 'Mo-Fr 10:00-18:00', 1),
(6, 6, 6, 'Gut', 30, 'Dresden, Zwinglistra�e 3', 'Mo-Fr 10:00-18:00', 1),
(7, 7, 7, 'Sehr gut', 30, 'Dresden, Ostra-Allee 7', 'Mo-Fr 10:00-18:00', 1),
(8, 8, 8, 'Gut', 30, 'Dresden, Schandauer Stra�e 2', 'Mo-Fr 10:00-18:00', 1),
(9, 9, 9, 'Akzeptabel', 30, 'Dresden, Wiener Stra�e 8', 'Mo-Fr 10:00-18:00', 1),
(10, 10, 10, 'Gut', 30, 'Dresden, Gro�enhainer Stra�e 15', 'Mo-Fr 10:00-18:00', 1);

-- Dummy-Daten f�r Standorte
INSERT INTO Standorte (StandortID, BenutzerID, Latitude, Longitude) VALUES 
(1, 1, 51.050407, 13.737262),
(2, 2, 51.050407, 13.737262),
(3, 3, 51.050407, 13.737262),
(4, 4, 51.050407, 13.737262),
(5, 5, 51.050407, 13.737262),
(6, 6, 51.050407, 13.737262),
(7, 7, 51.050407, 13.737262),
(8, 8, 51.050407, 13.737262),
(9, 9, 51.050407, 13.737262),
(10, 10, 51.050407, 13.737262);
