-- Tabelle Verlage erstellen
CREATE TABLE Verlage (
VerlagID INT PRIMARY KEY, -- Eindeutige Identifikation jedes Verlags
Name VARCHAR(100), -- Name des Verlags
Adresse VARCHAR(200) -- Adresse des Verlags
);

-- Tabelle Kategorien erstellen
CREATE TABLE Kategorien (
KategorieID INT PRIMARY KEY, -- Eindeutige Identifikation jeder Kategorie
Name VARCHAR(100) -- Name der Kategorie
);

-- Tabelle Benutzende erstellen
CREATE TABLE Benutzende (
BenutzerID INT PRIMARY KEY, -- Eindeutige Identifikation jedes Benutzers
Name VARCHAR(100), -- Name des Benutzers
Adresse VARCHAR(200), -- Adresse des Benutzers
Geburtsdatum DATE, -- Geburtsdatum des Benutzers
Telefonnummer VARCHAR(15), -- Telefonnummer des Benutzers
Email VARCHAR(100), -- E-Mail-Adresse des Benutzers
Passwort VARCHAR(255), -- Passwort des Benutzers (verschl�sselt)
Registrierungsdatum DATE -- Datum der Registrierung
);

-- Tabelle B�cher erstellen
CREATE TABLE B�cher (
BuchID INT PRIMARY KEY, -- Eindeutige Identifikation jedes Buches
Titel VARCHAR(200), -- Titel des Buches
ISBN CHAR(13), -- ISBN des Buches, festgelegt auf 13 Zeichen (ISBN-13
VerlagID INT, -- Fremdschl�ssel zu Verlage, um die Beziehung zum Verlag herzustellen
KategorieID INT, -- Fremdschl�ssel zu Kategorien, um die Beziehung zur Kategorie herzustellen
JahrDerVeroeffentlichung INT, -- Jahr der Ver�ffentlichung des Buches
Sprache CHAR(2), -- Sprache des Buches, festgelegt auf 2 Zeichen nach ISO-639-1
Zustand VARCHAR(100), -- Zustand des Buches (z.B. Neu, Gebraucht)
FOREIGN KEY (VerlagID) REFERENCES Verlage(VerlagID), -- Fremdschl�sselverkn�pfung: Verbindet B�cher mit Verlagen
FOREIGN KEY (KategorieID) REFERENCES Kategorien(KategorieID) -- Fremdschl�sselverkn�pfung: Verbindet B�cher mit Kategorien
);

-- Erstellen von Indexen auf der Tabelle "B�cher" zur Verbesserung der Suchgeschwindigkeit
CREATE INDEX idx_b�cher_titel ON B�cher(Titel); -- Index auf Titel-Spalte

CREATE INDEX idx_b�cher_sprache ON B�cher(Sprache); -- Index auf Sprache-Spalte

-- Tabelle Autoren erstellen
CREATE TABLE Autoren (
AutorID INT PRIMARY KEY, -- Eindeutige Identifikation jedes Autors
Name VARCHAR(100) -- Name des Autors
);

-- Tabelle BuchAutoren erstellen
CREATE TABLE BuchAutoren (
BuchID INT, -- Fremdschl�ssel zu B�cher
AutorID INT, -- Fremdschl�ssel zu Autoren
PRIMARY KEY (BuchID, AutorID), -- Kombinierter Prim�rschl�ssel
FOREIGN KEY (BuchID) REFERENCES B�cher(BuchID), -- Fremdschl�sselverkn�pfung: Verbindet BuchAutoren mit B�cher
FOREIGN KEY (AutorID) REFERENCES Autoren(AutorID) -- Fremdschl�sselverkn�pfung: Verbindet BuchAutoren mit Autoren
);

-- Tabelle Ausleihen erstellen
CREATE TABLE Ausleihen (
AusleihID INT PRIMARY KEY, -- Eindeutige Identifikation jeder Ausleihe
BenutzerID INT, -- Fremdschl�ssel zu Benutzende
BuchID INT, -- Fremdschl�ssel zu B�cher
Ausleihdatum DATE, -- Datum der Ausleihe
Rueckgabedatum DATE, -- Datum der R�ckgabe
FOREIGN KEY (BenutzerID) REFERENCES Benutzende(BenutzerID), -- Fremdschl�sselverkn�pfung: Verbindet Ausleihen mit Benutzenden
FOREIGN KEY (BuchID) REFERENCES B�cher(BuchID) -- Fremdschl�sselverkn�pfung: Verbindet Ausleihen mit B�chern
);

-- Tabelle Bewertungen erstellen
CREATE TABLE Bewertungen (
BewertungID INT PRIMARY KEY, -- Eindeutige Identifikation jeder Bewertung
BenutzerID INT, -- Fremdschl�ssel zu Benutzende
BuchID INT, -- Fremdschl�ssel zu B�cher
Bewertung TEXT, -- Bewertungstext
BewertungDatum DATE, -- Datum der Bewertung
FOREIGN KEY (BenutzerID) REFERENCES Benutzende(BenutzerID), -- Fremdschl�sselverkn�pfung: Verbindet Bewertungen mit Benutzenden
FOREIGN KEY (BuchID) REFERENCES B�cher(BuchID) -- Fremdschl�sselverkn�pfung: Verbindet Bewertungen mit B�chern
);

-- Tabelle Reservierungen erstellen
CREATE TABLE Reservierungen (
ReservierungsID INT PRIMARY KEY, -- Eindeutige Identifikation jeder Reservierung
BenutzerID INT, -- Fremdschl�ssel zu Benutzende
BuchID INT, -- Fremdschl�ssel zu B�cher
Reservierungsdatum DATE, -- Datum der Reservierung
FOREIGN KEY (BenutzerID) REFERENCES Benutzende(BenutzerID), -- Fremdschl�sselverkn�pfung: Verbindet Reservierungen mit Benutzenden
FOREIGN KEY (BuchID) REFERENCES B�cher(BuchID) -- Fremdschl�sselverkn�pfung: Verbindet Reservierungen mit B�chern
);

-- Tabelle Mahnungen erstellen
CREATE TABLE Mahnungen (
MahnungID INT PRIMARY KEY, -- Eindeutige Identifikation jeder Mahnung
AusleihID INT, -- Fremdschl�ssel zu Ausleihen
Mahndatum DATE, -- Datum der Mahnung
Betrag DECIMAL(5,2), -- Betrag der Mahnung
FOREIGN KEY (AusleihID) REFERENCES Ausleihen(AusleihID) -- Fremdschl�sselverkn�pfung: Verbindet Mahnungen mit Ausleihen
);

-- Tabelle Benachrichtigungen erstellen
CREATE TABLE Benachrichtigungen (
BenachrichtigungID INT PRIMARY KEY, -- Eindeutige Identifikation jeder Benachrichtigung
BenutzerID INT, -- Fremdschl�ssel zu Benutzende
Nachricht TEXT, -- Benachrichtigungstext
GesendetAm DATE, -- Datum der Benachrichtigung
FOREIGN KEY (BenutzerID) REFERENCES Benutzende(BenutzerID) -- Fremdschl�sselverkn�pfung: Verbindet Benachrichtigungen mit Benutzenden
);

-- Tabelle BenutzerB�cher erstellen
CREATE TABLE BenutzerB�cher (
BenutzerBuchID INT PRIMARY KEY, -- Eindeutige Identifikation jedes Eintrags
BenutzerID INT, -- Fremdschl�ssel zu Benutzende
BuchID INT, -- Fremdschl�ssel zu B�cher
Zustand VARCHAR(100), -- Zustand des Buches
VerleihDauer INT, -- Dauer der Ausleihe in Tagen
Abholort VARCHAR(200), -- Abholort des Buches
Zeitslots TEXT, -- Verf�gbare Zeitslots
VersandOption BIT, -- Versandoption (1 f�r ja, 0 f�r nein)
FOREIGN KEY (BenutzerID) REFERENCES Benutzende(BenutzerID), -- Fremdschl�sselverkn�pfung: Verbindet BenutzerB�cher mit Benutzenden
FOREIGN KEY (BuchID) REFERENCES B�cher(BuchID) -- Fremdschl�sselverkn�pfung: Verbindet BenutzerB�cher mit B�chern
);

-- Tabelle Standorte erstellen
CREATE TABLE Standorte (
StandortID INT PRIMARY KEY, -- Eindeutige Identifikation jedes Standortes
BenutzerID INT, -- Fremdschl�ssel zu Benutzende
Latitude DECIMAL(9,6), -- Breitengrad des Standorts
Longitude DECIMAL(9,6), -- L�ngengrad des Standorts
FOREIGN KEY (BenutzerID) REFERENCES Benutzende(BenutzerID) -- Fremdschl�sselverkn�pfung: Verbindet Standorte mit Benutzenden
);