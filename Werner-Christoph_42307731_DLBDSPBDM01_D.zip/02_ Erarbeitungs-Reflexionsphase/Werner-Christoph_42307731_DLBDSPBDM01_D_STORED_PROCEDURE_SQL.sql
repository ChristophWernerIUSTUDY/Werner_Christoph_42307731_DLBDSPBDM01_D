-- Erstellen einer Stored Procedure zum Einf�gen eines neuen Buches
-- Diese Prozedur kapselt den Einf�gevorgang in eine wiederverwendbare Einheit, die die Wartbarkeit und Sicherheit der Datenbank verbessert.

-- CREATE PROCEDURE: Definition einer neuen Prozedur namens 'InsertBook'
CREATE PROCEDURE InsertBook
    -- Definition der Eingabeparameter f�r die Prozedur
    @BuchID INT,                     -- Eindeutige Identifikation jedes Buches
    @Titel VARCHAR(200),             -- Titel des Buches
    @ISBN CHAR(13),                  -- ISBN des Buches, festgelegt auf 13 Zeichen (ISBN-13)
    @VerlagID INT,                   -- Fremdschl�ssel zu Verlage, um die Beziehung zum Verlag herzustellen
    @KategorieID INT,                -- Fremdschl�ssel zu Kategorien, um die Beziehung zur Kategorie herzustellen
    @JahrDerVeroeffentlichung INT,   -- Jahr der Ver�ffentlichung des Buches
    @Sprache CHAR(2),                -- Sprache des Buches, festgelegt auf 2 Zeichen nach ISO-639-1
    @Zustand VARCHAR(100)            -- Zustand des Buches (z.B. Neu, Gebraucht)
AS
BEGIN
    -- BEGIN ... END: Block, der die auszuf�hrenden Anweisungen der Prozedur enth�lt

    -- Einf�gen eines neuen Datensatzes in die Tabelle "B�cher"
    INSERT INTO B�cher (BuchID, Titel, ISBN, VerlagID, KategorieID, JahrDerVeroeffentlichung, Sprache, Zustand)
    VALUES (@BuchID, @Titel, @ISBN, @VerlagID, @KategorieID, @JahrDerVeroeffentlichung, @Sprache, @Zustand);

    -- Die Prozedur endet hier
END;
